package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import environment.DatabaseConnection;
import model.UserModel;

public class UserService {
	public String insertUser(UserModel userModel)
	{
		String status = "";
		DatabaseConnection.loadDriver();
		Connection conn = DatabaseConnection.getConnection();
		String sql = "insert into user values (?, ?, ?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userModel.getUname());
			ps.setString(2, userModel.getEmail());
			ps.setString(3, userModel.getPassword());
			ps.executeUpdate();
			status = "data entered successfully";
		} catch (SQLException e) {
			status = "data entered failed";
			e.printStackTrace();
		}
		return status;
	}
	
	public boolean validateUser(String email, String password)
	{
		boolean result = false; 
		DatabaseConnection.loadDriver();
		String sql = "select email, password from user where email = '"+ email +"' and password = '"+ password +"'";
		Connection conn = DatabaseConnection.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet resultSet= st.executeQuery(sql);
			
			if(resultSet == null){
				return false;
			}
			
			while(resultSet.next())
			{
				if (resultSet.getString("email").equals(email) && resultSet.getString("password").equals(password)) 
				{
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}

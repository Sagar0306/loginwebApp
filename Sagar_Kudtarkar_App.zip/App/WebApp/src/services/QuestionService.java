package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import environment.DatabaseConnection;
import model.QuestionModel;
import model.UserModel;

public class QuestionService {
	
	public String inserQuesion(QuestionModel questionModel)
	{
		String status = "";
		DatabaseConnection.loadDriver();
		Connection conn = DatabaseConnection.getConnection();
		String sql = "insert into questions values (?, ?, ?, ?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, questionModel.getQuestionId());
			ps.setString(2, questionModel.getEmail());
			ps.setString(3, questionModel.getQuestion());
			ps.setString(4, questionModel.getAnswer());
			ps.executeUpdate();
			status = "data entered successfully";
		} catch (SQLException e) {
			status = "data entered failed";
			e.printStackTrace();
		}
		return status;
	}
	
	public ResultSet getQuestionsBy(String email)
	{
		DatabaseConnection.loadDriver();
		String sql = "select question, answer from questions where email = '"+ email +"'";
		Connection conn = DatabaseConnection.getConnection();
		
		ResultSet resultSet = null;
			try {
				Statement st = conn.createStatement();
				resultSet = st.executeQuery(sql);
			} catch (Exception e) {
				e.printStackTrace();
			}	
		return resultSet;
	}
}

package model;

public class QuestionModel {
	String questionId, email, question, answer;

	public QuestionModel() {
		super();
	}

	public QuestionModel(String questionId, String email, String question, String answer) {
		super();
		this.questionId = questionId;
		this.email = email;
		this.question = question;
		this.answer = answer;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
}
